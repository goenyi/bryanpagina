
// carousel

ATVI.components.carousel = ATVI.components.carousel || {};
(function($, ATVI) {

    var car = ATVI.components.carousel;
    var registry = ATVI.utils.createRegistry("atvi-carousel");
	var slideRegistry = ATVI.utils.createRegistry("slide-container");

    car.init = function($el, opts) {

        var context = registry.get($el);
        if(context) return context;

        var reg = registry.register($el);
        context = reg.context;

        var w = reg.$el;
        context.wrapper = w;
        context.opts = opts;
        context.navs = [];

        var status = context.status = {
            last: -1,
            current: 0,
            wrapOnSwipe: true
        };

		status.$slides = w.find(".frame-inner").first().children(".slide-container").hide();
        status.slides = [];
        for(var i = 0; i < status.$slides.length; i++) {
            var $s = status.$slides.eq(i);
            var o = slideRegistry.get($s) || {};
            o.$el = $s;
            status.slides.push(o);
        }

        context.handleEvent = function(ev) {
			handleEvent(context, ev);
        };

        context.attachNav = function(nav) {
			attachNav(context, nav);
        };

        if(opts.nav && opts.nav.type != "none") {
            var nav = car.nav.build(status, opts.nav);
            if(nav) {
                w.find(".nav-container").last().append(nav.wrapper);
                context.attachNav(nav);
            }
        }

        initSlides(context);

        var ot = opts.transition;
        car.transitions.init(status, ot.type, ot.params);

        return context;
    };

    car.getContext = function($el) {
		return registry.get($el);
    };

    car.purgeContext = function($el) {
		return registry.purge($el);
    };

    car.purgeAllContexts = function() {
		registry.purgeAll();
    };

    var attachNav = function(context, nav) {
		nav.eventHandlers.push(context.handleEvent);
        context.navs.push(nav);
        updateNavs(context);
    };

    var updateNavs = function(context) {
        var navs = context.navs;
        for(var i = 0; i < navs.length; i++) {
			navs[i].update(context.status);
        };
    };

    var handleEvent = function(context, ev) {
		var handled = true;
        var info = {}, n = -2;
        var status = context.status;
        switch(ev.type) {
            case "next":
                if(status.current == status.slides.length - 1 && !status.wrapOnSwipe && ev.src == "swipe") handled = false;
                else {
                    info.delta = 1;
                    n = (status.current + 1) % status.slides.length;
                }
                break;

            case "prev":
                if(status.current == 0 && !status.wrapOnSwipe && ev.src == "swipe") handled = false;
                else {
                    info.delta = -1;
                    n = (status.current - 1 + status.slides.length) % status.slides.length;
                }
                break;

            case "seek":
                if(ev.index == status.current || ev.index >= status.slides.length || ev.index < 0) {
					handled = false;
                    break;
                }
                info.delta = ev.index - status.current;
				n = ev.index;
                break;

            default:
                handled = false;
        }

        if(handled) {
            if(n > -2) {
                status.last = status.current;
                status.current = n;
            }
            var cont = context.opts.transition;
            status.transitioning = true;
    		car.transitions.go(status, cont.type, info, cont.params);
            updateNavs(context);
        }
    };

    car.registerSlide = function($el, obj) {
		var reg = slideRegistry.register($el);
        $.extend(reg.context, obj);
        return reg.context;
    };

    car.getSlideContext = function($el) {
		return slideRegistry.get($el);
    };

    var initSlides = function(context) {

        if(!ATVI.browser.isTouch || (("addSwiping" in context.opts) && !context.opts.addSwiping)) return;

        var slides = context.status.slides;
        for(var i = 0; i < slides.length; i++) {
			var s = slides[i];
            if(s.swipeOverride) {
				if(typeof s.swipeOverride == "function") s.swipeOverride(status, s);
            } else {
                if(!s.$el.length) continue;

                ATVI.touch.onSimpleHorizontal(s.$el, {
                    swipeLeft: function(ev) {
                        var details = ATVI.analytics.findComponentId(context.wrapper);
                        ATVI.analytics.sendEvent("carousel-swipe", details, {
                            direction: "left", 
                            carousel_action: "next",
                            from_index: context.status.current
                        });
   						context.handleEvent({type: "next", src: "swipe"});
                    },
                    swipeRight: function(ev) {
						var details = ATVI.analytics.findComponentId(context.wrapper);
                        ATVI.analytics.sendEvent("carousel-swipe", details, {
                            direction: "right",
                            carousel_action: "previous",
                            from_index: context.status.current
                        });
   						context.handleEvent({type: "prev", src: "swipe"});
                    }
                });

            }
        }
    };

})(jQuery, ATVI);


// carousel-nav

(function($, ATVI) {

    var car = ATVI.components.carousel;
    var carnav = car.nav = car.nav || {};

    carnav.build = function(status, opts) {
		var b = carnav[opts.type];
        if(!b) b = carnav.default;
        return b.build(status, opts);
    };

    var buildBasicObject = function(type, status, opts) {
        var ret = {};
        var temps = carnav[type].templates;
        var text = opts.text;

        var wrapper = ret.wrapper = $('<div class="carousel-nav default">');
		ret.prev = $(ATVI.utils.renderTemplate(temps.prev, text)).appendTo(wrapper);
		var dc = ret.dotContainer = $('<div class="dot-container">').appendTo(wrapper);
		ret.next = $(ATVI.utils.renderTemplate(temps.next, text)).appendTo(wrapper);

        for(var i = 0; i < status.slides.length; i++) {
            text.i = i;
            text.iPlus1 = i + 1;
			$(ATVI.utils.renderTemplate(temps.dot, text)).appendTo(dc);
        }
        ret.dots = dc.find(".dot");

        ret.eventHandlers = [];

        ret.prev.click(function(e) {
			e.preventDefault();
            if(ret.disabled) return;
            notifyHandlers(ret, {type: "prev", src: "click"});
        });

        ret.next.click(function(e) {
			e.preventDefault();
            if(ret.disabled) return;
            notifyHandlers(ret, {type: "next", src: "click"});
        });

        ret.dots.click(function(e) {
            e.preventDefault();
            if(ret.disabled) return;
            var i = ret.dots.index(this);
            notifyHandlers(ret, {type: "seek", index: i, src: "click", el: "dot"});
        });

        ret.update = function(status) {
			ret.dots.removeClass("current");
            var i = status.current;
            if(i >= 0 && i < ret.dots.length) {
				ret.dots.eq(i).addClass("current");
            }
        };

        ret.disable = function() { ret.disabled = true; };
		ret.enable = function() { ret.disabled = false; };

		ATVI.analytics.setupClickHandlers(wrapper);

        return ret;
    };

    var notifyHandlers = function(obj, ev) {
        var eh = obj.eventHandlers;
        for(var i = 0; i < eh.length; i++) {
            eh[i](ev);
        }
    };

    var basic = carnav.basic = {};
    basic.templates = {
        prev: '<a href="#" title="{{previous}}" class="previous button atvi-instrument atvi-instrument-carousel-nav-previous">{{previous}}</a>',
		next: '<a href="#" title="{{next}}" class="next button atvi-instrument atvi-instrument-carousel-nav-next">{{next}}</a>',
        dot: '<a href="#" title="{{iPlus1}}" class="dot dot-{{i}} atvi-instrument atvi-instrument-carousel-nav-dot"><div class="dot-inner">{{iPlus1}}</div></a>'
    };

    basic.build = function(status, opts) {
        var ret = buildBasicObject("default", status, opts);
		// add thumbnails?
        return ret;
    };

    // set default to basic
    carnav.default = carnav.default || carnav.basic;

})(jQuery, ATVI);


// carousel-transitions

(function($, ATVI) {

    var car = ATVI.components.carousel;
    var cart = car.transitions = car.transitions || {};

    cart.init = function(status, type, params) {
		var t = cart[type];
        if(!t) t = cart.default;
        t.init(status, params);
    };

    cart.go = function(status, type, info, params) {
		var t = cart[type];
        if(!t) t = cart.default;
        t.go(status, info, params);
    };

    var getDefaults = function(a, def) {
        var r = (a || []).slice();
        for(var i = 0; i < def.length; i++) {
			if(r[i] === undefined) r[i] = def[i];
        }
        return r;
    };

    var parseParams = function(p) {
        if($.isArray(p)) return p;
		var r = (p || "").trim().split(/\s+/);
        if(r.length == 1 && r[0] == "") r = [];
        return r;
    };

    var updateSlide = function(obj, name, status, x, dist) {
        if(obj[name]) {
            obj[name](status, x, dist);
            return true;
        }
    };

    var preEnter = function(obj, status) { return updateSlide(obj, "preEnter", status); };
    var startEnter = function(obj, status) { return updateSlide(obj, "startEnter", status); };
    var enterStep = function(obj, status, x, dist) { return updateSlide(obj, "enterStep", status, x, dist); };
	var endEnter = function(obj, status) { return updateSlide(obj, "endEnter", status); };
    var startExit = function(obj, status) { return updateSlide(obj, "startExit", status); };
    var endExit = function(obj, status) { return updateSlide(obj, "endEnter", status); };
    var exitStep = function(obj, status, x, dist) { return updateSlide(obj, "exitStep", status, x, dist); };

	// general slide

    var slide = cart.slide = {};

    slide.init = function(status, params, wrap) {
        status.animDiv = $("<div>");
        status.wrapOnSwipe = wrap;

        var slides = status.slides;
		var base = -status.current;

        if(!wrap) {
			setSlidePositions(slides, slides.length, base); 
        } else {
            var half = slides.length * .5;
            if(base < -half) base += slides.length;
			setSlideWrapPositions(slides, slides.length, half, base); 
        }
        status.$slides.show();

        var curr = status.slides[status.current];
        curr.$el.addClass("current");

        preEnter(curr, status);
		startEnter(curr, status);
        endEnter(curr, status);

    };

    slide.go = function(status, info, params, wrap) {
        var curr = status.slides[status.last];
        var next = status.slides[status.current];
        var currEl = curr.$el.removeClass("current");
        var nextEl = next.$el.addClass("current");

        var def = getDefaults(parseParams(params), [500, "easeInOutQuad"]);
		var duration = parseInt(def[0]);
        var easing = def[1];

        var slides = status.slides;
		var base = -status.last;
        var delta = -status.current - base;
        var setPositions, l = slides.length;
		var half = l * .5;

        if(!wrap) {
			setPositions = function(x) {
                var p = base + x * delta;
                if(status.positionHandler) status.positionHandler(status, p);
				setSlidePositions(slides, l, p);
                return p;
        	};
        } else {
			if(base < -half) base += l;
            if(delta < -half) delta += l;
            else if(delta > half) delta -= l;

            setPositions = function(x) {
                var p = base + x * delta;
                if(status.positionHandler) status.positionHandler(status, p);
				setSlideWrapPositions(slides, l, half, p);
                return p;
        	};
        }

        var div = status.animDiv;
        div.queue(function(next) {
			div.css("left", 0);
			preEnter(next, status);
            startEnter(next, status);
            startExit(curr, status);
            var animOpts = {
                duration: duration,
                easing: easing,
                step: function(x) {
					var p = setPositions(x);
                    var currDist = normalizePosition(l, half, status.last + p);
                    var nextDist = normalizePosition(l, half, status.current + p);
                    exitStep(curr, status, x, currDist);
                    enterStep(next, status, x, nextDist);
                },
                done: function() {
                    setPositions(1);
                    endExit(curr, status);
                    endEnter(next, status);
                }
            };
			next();
            div.animate({left: 1}, animOpts);
        });
    };

	var setSlidePositions = function(slides, l, zeroPos) {
        for(var i = 0; i < l; i++) {
            slides[i].$el[0].style.left = ((zeroPos + i) * 100) + "%";
        }
    };

    var setSlideWrapPositions = function(slides, l, half, zeroPos) {
        for(var i = 0; i < l; i++) {
            var sp = normalizePosition(l, half, zeroPos + i);
            slides[i].$el[0].style.left = (sp * 100) + "%";
        }
    };

    var normalizePosition = function(l, half, x) {
		while(x < -half) x += l;
		while(x > half) x -= l;
		return x;
    };

	// slide with wrap-around

    var slideWrap = cart.slideWrap = {};
    slideWrap.init = function(status, params) {
		slide.init(status, params, true);
    };
    slideWrap.go = function(status, info, params) {
		slide.go(status, info, params, true);
    };

    var flip = cart.flip = {};
    flip.init = function(status, params) {
		slide.init(status, "0", true);
    };
    flip.go = function(status, info, params) {
		slide.go(status, info, "0", true);
    };

	// crossfade

    var cfade = cart.crossfade = {};
    cfade.init = function(status, params) {
        status.$slides.parents(".atvi-carousel").first().addClass("transition-cfade")
        status.$slides.hide();
        var curr = status.slides[status.current];
        preEnter(curr, status);
        if(!startEnter(curr, status)) curr.$el.addClass("current").show();
		endEnter(curr, status);
    };

    cfade.go = function(status, info, params) {
        var def = getDefaults(parseParams(params), [500, 500, 0, "easeInOutQuad"]);

        var curr = status.slides[status.last];
        var next = status.slides[status.current];
        var currEl = curr.$el;
        var nextEl = next.$el;

        // fade out
        var fadeout = parseInt(def[0]);
        if(fadeout < 0) fadeout = 0;
        startExit(curr, status);

        var outOpts = {
            duration: fadeout,
            easing: def[3],
            done: function() {
                currEl.hide();
                endExit(curr, status);
        	}
        };
        if(curr.exitStep) {
            outOpts.step = function() {
				var x = parseFloat(currEl.css("opacity"));
				exitStep(curr, status, 1 - x, x);
            };
        }
        currEl.stop(true).animate({opacity: 0}, outOpts);

        // fade in
        var fadein = parseInt(def[1]);
        if(fadein < 0) fadin = 0;
        var fadeinDelay = parseInt(def[2]);
		preEnter(next, status);

        nextEl.stop(true).delay(fadeinDelay).queue(function() {
            currEl.removeClass("current")
            nextEl.addClass("current").css("opacity", 0).show().insertAfter(currEl);
		    startEnter(next, status);
            var opts = {
                duration: fadein,
                easing: def[3],
                done: function() {
					endEnter(next, status);
                }
            };
            if(next.enterStep) {
                opts.step = function() {
					var x = parseFloat(nextEl.css("opacity"));
                    enterStep(next, status, x, 1 - x);
                };
            }
            nextEl.animate({opacity: 1}, opts);
            nextEl.dequeue();
        });
    };

    // fade in / out
    
    var fade = cart.fade = {};
    fade.makeParams = function(params) {
        var p = parseParams(params);
		var d = getDefaults(p, [500, 500, "easeInOutQuad"]);
        return [d[0], d[1], d[0], d[2]];
    };
    fade.init = function(status, params) {
        cfade.init(status, fade.makeParams(params));
    };
    fade.go = function(status, info, params) {
    	cfade.go(status, info, fade.makeParams(params));
    };

    // set default to slide
    cart.default = cart.default || cart.slide;

})(jQuery, ATVI);


ATVI.library.registerLibrary("carousel");

