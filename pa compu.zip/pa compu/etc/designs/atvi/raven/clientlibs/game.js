var Raven = Raven || {};

Raven.header = {};

(function($, Raven) {

    var $menu;

    var init = function() {
        console.log("INIT HEADER");

        setupMenuToggle();
        setupActiveLink();
        resize();
    };

    var setupMenuToggle = function() {
        var $toggle = $(".menu-toggle");
        $menu = $(".header-container .main-menu");
        $toggle.click(function() {
            $("html").toggleClass("menu");
            if($menu.is(":visible")) $menu.fadeOut();
            else $menu.fadeIn();

        });
    };

    var setupActiveLink = function() {
        var url = window.location.href;
        if(url.indexOf("games") > 0) $menu.find("li:eq(0)").addClass("active");
        if(url.indexOf("about") > 0) $menu.find("li:eq(1)").addClass("active");
    };

    var resize = function() {
        $(window).resize(function() {
            if(window.innerWidth >= 768) {
                $("html").removeClass("menu");
                $menu.show();
            } else {
                if($("html").hasClass("menu")) $menu.show();
                else $menu.hide();
            }
        });
    };

    Raven.header.init = init;

})(jQuery, Raven);

var Raven = Raven || {};

Raven.games = {};

(function($, Raven) {

    var $container, desktopIdx, mobileIdx, desktopMode, animation;

    var init = function() {
        console.log("INIT GAMES");

        if(ATVI.pageMode != "edit") { 
            defineVars();
            checkMode();
            setupNavigation();
            checkArrowStatus();
            setupSlides();
            setupSlidesPosition();

            resize();
    
            $(window).load(function(){ 
                equalizeHeights();
                $container.fadeTo("slow", 1.0);
            });

            initSwipe();
        }
    };

    var defineVars = function() {
        desktopIdx = 0;
        mobileIdx = 0;
        animation = false;
        desktopMode = (window.innerWidth > 640) ? true : false;
        $container = $("#raven-games");
        $entries = $container.find(".content-tile-entry");
        $container.css("opacity","0");
    };
       
    var setupNavigation = function() {
        var $leftArrow = $("<div class='prev' id='prev'/>").prependTo($("#raven-games"));
        var $rightArrow = $("<div class='next' id='next'/>").prependTo($("#raven-games"));

        $leftArrow.click(function() { 

            if(animation) return;

            if(desktopMode) {
                desktopIdx--;
                if(desktopIdx < 0) desktopIdx = getNumSlides() - 1;
            } else {
                mobileIdx--;
                if(mobileIdx < 0) mobileIdx = getNumSlides() - 1;
            }

            var curIdx = (desktopMode) ? desktopIdx : mobileIdx;

            if(desktopMode) {
                animation = true;
                if(curIdx < 0) return;
                $container.find(".slide").animate({left : "+=100%"}, 500, function(){
                    checkArrowStatus();
                    $container.find(".slide").removeClass("active");
                    $container.find(".slide:eq(" + desktopIdx + ")").addClass("active");
                    animation = false;
                });
            } else {
                animation = true;
                var $activeSlide = $container.find(".slide.active")
                var $prevSlide = $activeSlide.prev(".slide");
                if($prevSlide.length <= 0) $prevSlide = $container.find(".slide:eq(" + (getNumSlides() - 1) + ")");

                $prevSlide.css("left", "-100%").show().animate({left: "0%"}, 500);

                $activeSlide.animate({left : "100%"}, 500, function() {
                    $activeSlide.attr("style","");
                    $activeSlide.removeClass("active");
                    $prevSlide.addClass("active");
                    animation = false;
                });
            }

        });

        $rightArrow.click(function() {

            if(animation) return;

            if(desktopMode) {
                desktopIdx++;
                if(desktopIdx == getNumSlides()) desktopIdx = 0;
            } else {
                mobileIdx++;
                if(mobileIdx == getNumSlides()) mobileIdx = 0;
            }

            var curIdx = (desktopMode) ? desktopIdx : mobileIdx;

            if(desktopMode) {
                animation = true;
                if(curIdx >= $container.find(".slide").length) return;
                $container.find(".slide").animate({left : "-=100%"}, 500, function(){
                    checkArrowStatus();
                    $container.find(".slide").removeClass("active");
                    $container.find(".slide:eq(" + desktopIdx + ")").addClass("active");
                    animation = false;
                });
            } else {
                animation = true;
                var $activeSlide = $container.find(".slide.active")
                var $nextSlide = $activeSlide.next(".slide");
                if($nextSlide.length <= 0) $nextSlide = $container.find(".slide:eq(0)");

                $nextSlide.css("left", "100%").show().animate({left: "0%"}, 500);

                $activeSlide.animate({left : "-100%"}, 500, function() {
                    $activeSlide.attr("style","");
                    $activeSlide.removeClass("active");
                    $nextSlide.addClass("active");
                    animation = false;
                });

            }
        });
    };

    var setupSlides = function() {

        var entriesPerSlide;
        var curIdx;

        if(!desktopMode) {
            entriesPerSlide = 1; 
            curIdx = mobileIdx;
        }else {
            entriesPerSlide = (window.innerWidth > 1200) ? 3 : 1; 
            curIdx = desktopIdx;
        }

        if($container.find(".slide").length) $entries.unwrap();
        for(var i = 0; i < $entries.length; i+=entriesPerSlide) {
            $entries.slice(i, i+entriesPerSlide).wrapAll("<div class='slide'></div>");
        }

        $container.find(".slide:eq(" + curIdx + ")").addClass("active");

    };

    var setupSlidesPosition = function() {

        if(!desktopMode) return;

        var $slides = $container.find(".slide");
        var numSlides = getNumSlides();

        var curIdx = desktopIdx;

        for(var i = 0; i < numSlides; i++) {
            var left = (i*100) - (100*curIdx);
            $slides.filter(":eq(" + i + ")").css("left",left + "%");
        }

    };

    var checkArrowStatus = function(arrow) {

        var curIdx = desktopIdx;

        var $leftArrow = $container.find(".prev");
        var $rightArrow = $container.find(".next");


        if(curIdx == 0 && desktopMode) {
            $leftArrow.hide();
            $rightArrow.show(); 
        } else if(curIdx == ($container.find(".slide").length - 1) && desktopMode) {
            $leftArrow.show();   
            $rightArrow.hide();
        } else {
            $leftArrow.show();  
            $rightArrow.show();
        }

    };

    var getNumSlides = function() {
        var $slides = $container.find(".slide");
        var numSlides = $slides.length;
        return numSlides;
    };

    var checkMode = function() {

        var newMode = (window.innerWidth > 1200) ? true : false;

        if(newMode && desktopMode) {
            //mode was already in desktopmode so no need to call anything
            //console.log("Already in desktop mode");
        } else if(newMode && !desktopMode) {
            //it switched from mobile to desktop
            desktopMode = true;
            setupSlides();
            setupSlidesPosition();
            checkArrowStatus();
            //console.log("Change from mobile to desktop");
        } else if(!newMode && desktopMode) {
            //it switched from desktop to mobile
            desktopMode = false;
            setupSlides();
            checkArrowStatus();
            //console.log("Change from desktop to mobile");
        } else if (!newMode && !desktopMode) {
            //mode is already in mobile mode so no need to call anything
            //console.log("Already in mobile mode");
        }
    };

    var equalizeHeights = function() {

        var $imgContainers = $container.find(".child-slide-image");

        if(window.innerWidth <= 1200) {
            $imgContainers.attr("style","");
            return;
        }

        var maxHeight = 0;
        $imgContainers.css("height", "auto");

        $imgContainers.each(function() {
            var h = $(this).height();
            if(h > maxHeight) maxHeight = h;
        });

        $imgContainers.height(maxHeight);

    };

    var initSwipe = function() {
        ATVI.touch.onSimpleHorizontal($container, {
            swipeRight: function() {
                if($container.find(".prev").is(":visible")) $container.find(".prev").click();
            },
            swipeLeft: function() { 
                if($container.find(".next").is(":visible")) $container.find(".next").click();
            }
        });
    };

    var resize = function() {
        $(window).resize(function() {
            checkMode();
            equalizeHeights();
        });
    };

    $(init);

})(jQuery, Raven);


var Raven = Raven || {};

Raven.core = {};

(function($, Raven) {

    var core = Raven.core, $body;

    var init = function() {
        $(postload);
        preload();
    };

    var preload = function() {

    };

    var postload = function() {
        Raven.core.loaded = true;
        $body = $("body");
        
        console.log("CORE LOADED");
        Raven.header.init();
        //backgroundImg();
        fadeMenus();
    };
	/*
    var backgroundImg = function() {
        var $bgImg = $("<div class='bkg-img' />").prependTo($("body"));
    };
	*/
    var fadeMenus = function() {
        $(window).load(function(){
            setTimeout(function(){
                $(".header-container, .footer-container").addClass("ready");
            }, 500);
        });
    };

    Raven.core.init = init;
    
})(jQuery, Raven);

Raven.core.init();




