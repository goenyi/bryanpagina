
(function() {

    WebFontConfig = {
    google: { families: [ 'Droid+Sans:400,700:latin' ] }
  };
  (function() {
    var wf = document.createElement('script');
    wf.src = 'https://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js';
    wf.type = 'text/javascript';
    wf.async = 'true';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(wf, s);
  })(); 
    
})();

(function() {

    WebFontConfig = {
    google: { families: [ 'Cabin:700,400,600,400italic,500,500italic,600italic,700italic:latin' ] }
  };
  (function() {
    var wf = document.createElement('script');
    wf.src = 'https://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js';
    wf.type = 'text/javascript';
    wf.async = 'true';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(wf, s);
  })(); 
    
})();




$(document).ready(function () {

	//set hidden hamburger menu
    $( ".menu" ).hide();
    $( ".hamburger" ).click(function() {
        $( ".menu" ).slideToggle( "slow", function() {
            $( ".hamburger" ).show();
        }); 
        //fix raven game arrow z-index issue
        $("#prev").toggle();
        $("#next").toggle();
		$("a[title='Next']").css('z-index','0');
        $("a[title='Previous']").css('z-index','0');  
    }); 



	//hightlight current url
    var highlightNav = function(current){

        var navs = $(".raven-nav-right ul li a");
        var len = navs.length;

        for( i = 0 ; i < len ; i++){

            $currentNav = navs[i];
            className = $currentNav.className;

            if( current.indexOf(className) >= 0)  $currentNav.className += ' currentNav';
        }
    };

    highlightNav(window.location.href);
    
});  
//hide arrows

$(document).ready(function(){

    var numSlides = $(".slide-image").length;
	var current = $(location).attr('href');
    $prev = $(".previous");
    $next = $(".next");


    if( numSlides <= 1 && current.indexOf("career") >=0 && $(".cq-wcm-edit").length == 0 ) {  
		$prev.hide();
        $next.hide();
    }

});

$(document).ready(function(){

    var len = $(".slide-container").length;
    var notOnCQ = ($(".multi-entry-header").length == 0);


	//fix z-index issue
    setIndex = function(){
		$(".slide-container.current").css('z-index','0');
    };
	//rotate carousel
    nextSlide = function(){
      	$( "#hero-carousel-test .next" ).trigger( "click" );
    };


	setInterval(function(){ 
        if( notOnCQ ) nextSlide();
    }, 4000); 

    if( notOnCQ ) {

		setIndex();

        $( ".previous" ).click(function() {
            setIndex();
        });

        $( ".next" ).click(function() {
            setIndex();
        });
    }

});



